import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(PersonalJournalApp());
}

class PersonalJournalApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Personal Journal',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        scaffoldBackgroundColor: Colors.grey[50],
      ),
      home: JournalHomePage(),
    );
  }
}

class JournalHomePage extends StatefulWidget {
  @override
  _JournalHomePageState createState() => _JournalHomePageState();
}

class _JournalHomePageState extends State<JournalHomePage> {
  int _selectedIndex = 0;
  List<Map<String, dynamic>> _notes = [];
  final picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<String> get _localPath async {
    if (kIsWeb) {
      return '';
    }
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  Future<File?> get _localFile async {
    if (kIsWeb) return null;
    final path = await _localPath;
    return File('$path/journal.json');
  }

  Future<void> _loadData() async {
    try {
      if (kIsWeb) {
        // Load from localStorage untuk web (belum diimplementasi)
        return;
      }
      final file = await _localFile;
      if (file != null && await file.exists()) {
        final contents = await file.readAsString();
        setState(() {
          _notes = List<Map<String, dynamic>>.from(json.decode(contents));
        });
      }
    } catch (e) {
      print("Error loading: $e");
    }
  }

  Future<void> _saveData() async {
    try {
      if (kIsWeb) {
        // Save to localStorage untuk web (belum diimplementasi)
        return;
      }
      final file = await _localFile;
      if (file != null) {
        await file.writeAsString(json.encode(_notes));
      }
    } catch (e) {
      print("Error saving: $e");
    }
  }

  Future<void> _showAddDialog() async {
    final titleController = TextEditingController();
    final contentController = TextEditingController();
    XFile? imageFile;
    String? imageData;

    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text("Tambah Catatan"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: titleController,
                      decoration: InputDecoration(
                        labelText: "Judul",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: contentController,
                      decoration: InputDecoration(
                        labelText: "Isi Catatan",
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                    SizedBox(height: 10),
                    ElevatedButton.icon(
                      onPressed: () async {
                        final picked = await picker.pickImage(
                          source: ImageSource.gallery,
                        );
                        if (picked != null) {
                          // Convert to base64 for cross-platform compatibility
                          final bytes = await picked.readAsBytes();
                          final base64Image = base64Encode(bytes);

                          setState(() {
                            imageFile = picked;
                            imageData = base64Image;
                          });
                        }
                      },
                      icon: Icon(Icons.image),
                      label: Text("Pilih Gambar"),
                    ),
                    if (imageData != null)
                      Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: Image.memory(
                          base64Decode(imageData!),
                          height: 100,
                        ),
                      ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text("Batal"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (titleController.text.isNotEmpty) {
                      this.setState(() {
                        _notes.insert(0, {
                          "id": DateTime.now().millisecondsSinceEpoch,
                          "title": titleController.text,
                          "content": contentController.text,
                          "image": imageData ?? "",
                          "date": DateTime.now().toString().substring(0, 16),
                        });
                      });
                      _saveData();
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Catatan berhasil disimpan!")),
                      );
                    }
                  },
                  child: Text("Simpan"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _deleteNote(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Hapus Catatan"),
        content: Text("Yakin ingin menghapus?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _notes.removeAt(index);
              });
              _saveData();
              Navigator.pop(context);
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text("Catatan dihapus")));
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text("Hapus"),
          ),
        ],
      ),
    );
  }

  Widget _buildImage(String imageData, {double? width, double? height}) {
    if (imageData.isEmpty) {
      return Icon(Icons.note, size: 40);
    }

    try {
      return Image.memory(
        base64Decode(imageData),
        width: width,
        height: height,
        fit: BoxFit.cover,
      );
    } catch (e) {
      return Icon(Icons.broken_image, size: 40);
    }
  }

  Widget _buildHomeTab() {
    if (_notes.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.note_outlined, size: 80, color: Colors.grey),
            SizedBox(height: 10),
            Text("Belum ada catatan", style: TextStyle(fontSize: 18)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.all(10),
      itemCount: _notes.length,
      itemBuilder: (context, index) {
        final note = _notes[index];
        return Card(
          margin: EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: _buildImage(note["image"] ?? "", width: 50, height: 50),
            title: Text(
              note["title"],
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              "${note["content"]}\n${note["date"]}",
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            isThreeLine: true,
            trailing: IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteNote(index),
            ),
          ),
        );
      },
    );
  }

  Widget _buildGalleryTab() {
    final images = _notes.where((n) => n["image"] != "").toList();

    if (images.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.photo_library, size: 80, color: Colors.grey),
            SizedBox(height: 10),
            Text("Belum ada foto", style: TextStyle(fontSize: 18)),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: EdgeInsets.all(10),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 5,
        mainAxisSpacing: 5,
      ),
      itemCount: images.length,
      itemBuilder: (context, index) {
        return _buildImage(images[index]["image"]);
      },
    );
  }

  Widget _buildStatsTab() {
    final total = _notes.length;
    final withImages = _notes.where((n) => n["image"] != "").length;

    return Padding(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Statistik",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Card(
            child: ListTile(
              leading: Icon(Icons.note, color: Colors.blue, size: 40),
              title: Text("Total Catatan"),
              trailing: Text(
                "$total",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: Icon(Icons.image, color: Colors.green, size: 40),
              title: Text("Dengan Foto"),
              trailing: Text(
                "$withImages",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: Icon(
                Icons.note_outlined,
                color: Colors.orange,
                size: 40,
              ),
              title: Text("Tanpa Foto"),
              trailing: Text(
                "${total - withImages}",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      _buildHomeTab(),
      _buildStatsTab(),
      _buildGalleryTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text("Personal Journal"),
        backgroundColor: Colors.deepPurple,
      ),
      body: pages[_selectedIndex],
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddDialog,
        child: Icon(Icons.add),
        backgroundColor: Colors.deepPurple,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.deepPurple,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: "Statistik",
          ),
          BottomNavigationBarItem(icon: Icon(Icons.photo), label: "Galeri"),
        ],
      ),
    );
  }
}
